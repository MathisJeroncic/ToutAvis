ToutAvis est un projet de Bibtel développé par Fanch et Mathis.

Vous trouverez dans ce dossier 4 dossiers sources : 
- exceptions contient les classes de levée d'exceptions
- hmi implémente une interface homme machine
- opinion contient le corps du développement, implémentant les fonctionnalités principales
- tests contient le test de l'ensemble des fonctions