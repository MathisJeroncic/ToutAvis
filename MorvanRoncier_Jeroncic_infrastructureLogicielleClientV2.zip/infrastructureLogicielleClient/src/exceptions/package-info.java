/** 
 * This package contains all the Exceptions.
 *  
 */
package exceptions;