/**
 * This package contains the main file of the ToutAvis project.
 */
package opinion;