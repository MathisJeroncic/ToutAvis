/**
 * This package contains files that allow to test the class.
 */

package tests;