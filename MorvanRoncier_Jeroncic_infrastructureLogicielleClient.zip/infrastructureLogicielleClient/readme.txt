Bonjour,

Soyez indulgents s'il vous plait, on fait de notre mieux mais on est un petit peu bête.
Le code n'est pas complet par manque de temps, mais vous pourrez y trouver un diagramme de classe ainsi qu'un diagramme de sequence afin de mieux comprendre le projet de notre vie : ToutAvis.
Pretez particulierement attention aux noms de fichiers qui contiennent "Member" ou encore "ItemBook".

Merci, ci la famille.

signé : Moiquoubeh