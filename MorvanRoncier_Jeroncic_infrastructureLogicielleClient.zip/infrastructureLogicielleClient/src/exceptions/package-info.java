/** 
 * Specific Exceptions for SocialNetwork
 *  
 */
package exceptions;