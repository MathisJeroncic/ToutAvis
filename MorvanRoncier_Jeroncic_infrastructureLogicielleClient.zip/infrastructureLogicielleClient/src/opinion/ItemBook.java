package opinion;

public class ItemBook {
	String title;
	String kind;
	String author;
	int nbPages;
}
